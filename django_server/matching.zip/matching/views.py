from django.shortcuts import render
import json
from django.http import JsonResponse,QueryDict,HttpResponse
from django.http.multipartparser import MultiPartParser

from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate
from rest_framework.decorators import api_view, permission_classes, authentication_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.response import Response
from rest_framework import status
from user_account.repository import user_auth_repository
from matching.repository import profile_repository
from .service import profile_service,s3_service

import logging

logger = logging.getLogger(__name__)
# Create your views here.
@csrf_exempt
@api_view(['GET','POST','PUT','DELETE'])
@permission_classes([IsAuthenticated])
# Handle requests for creating,deleting and updating profile
def handle_profile(request):
    if request.method == 'GET':
                try:
                    parsed_req= MultiPartParser(request.META, request, request.upload_handlers).parse()
                    body = parsed_req[0]
                    # get the user using repository method
                    user_auth_repository_var = user_auth_repository.UserAuthRepository()
                    user = user_auth_repository_var.get_user_by_email(body['emailId'])
                    if not user:
                        logger.error("User not Found {}".format(body['emailId']))
                        return JsonResponse({'error': f'Error user email: {str(body['emailId'])} not found'}, status=400)
                    profile_repo_obj = profile_repository.ProfileRepository()
                    profile = profile_repo_obj.get_profile_by_user_id(user)
                    if profile:
                        return JsonResponse({'message': 'Successfully fetched user','profile':list(profile.values())[0]})
                    else:
                        return JsonResponse({'error': f'Error fetching user: {str(body['emailId'])}'}, status=500)
                except KeyError as e:
                    # Return error response for missing required field
                    logger.error(e)
                    return JsonResponse({'error': f'Missing required field: {e}'}, status=400)
                except Exception as e:
                    # Return error response for any unexpected exception
                    logger.error(e)
                    return JsonResponse({'error': f'Error getching user: {str(e)}'}, status=500)
    if request.method == 'POST':
                try:
                    body = request.POST
                    # get the user using repository method
                    user_auth_repository_var = user_auth_repository.UserAuthRepository()
                    user = user_auth_repository_var.get_user_by_email(body['emailId'])
                    if not user:
                        logger.error("User not Found {}".format(body['emailId']))
                        return JsonResponse({'error': f'Error user email: {str(body['emailId'])} not found'}, status=400)
                    profile_service_obj = profile_service.ProfileService()
                    action = profile_service_obj.create_profile(body,request.FILES['profilePic'],request.FILES['avatar'],user)    
                    if action:
                        return JsonResponse({'message': 'Successfully created user'})
                    else:
                        return JsonResponse({'error': f'Error creating user: {str(body['emailId'])}'}, status=500)
                except KeyError as e:
                    # Return error response for missing required field
                    logger.error(e)
                    return JsonResponse({'error': f'Missing required field: {e}'}, status=400)
                except Exception as e:
                    # Return error response for any unexpected exception
                    logger.error(e)
                    return JsonResponse({'error': f'Error creating user: {str(e)}'}, status=500)
    elif request.method == 'PUT':
            try:
                parsed_req= MultiPartParser(request.META, request, request.upload_handlers).parse()
                body = parsed_req[0]
                files = parsed_req[1]
                # get the user using repository method
                user_auth_repository_var = user_auth_repository.UserAuthRepository()
                user = user_auth_repository_var.get_user_by_email(body['emailId'])
                if not user:
                    logger.error("User not Found {}".format(body['emailId']))
                    return JsonResponse({'error': f'Error user email: {str(body['emailId'])} not found'}, status=400)
                profile_service_obj = profile_service.ProfileService()
                action = profile_service_obj.update_profile(body,files['profilePic'],files['avatar'],user)    
                if action:
                    return JsonResponse({'message': 'Successfully updated user'})
                else:
                    return JsonResponse({'error': f'Error updating user: {str(body['emailId'])}'}, status=500)
            except KeyError as e:
                # Return error response for missing required field
                logger.error(e)
                return JsonResponse({'error': f'Missing required field: {e}'}, status=400)
            except Exception as e:
                # Return error response for any unexpected exception
                logger.error(e)
                return JsonResponse({'error': f'Error updating user: {str(e)}'}, status=500)
    elif request.method == 'DELETE':
            try:
                parsed_req= MultiPartParser(request.META, request, request.upload_handlers).parse()
                body = parsed_req[0]
                # get the user using repository method
                user_auth_repository_var = user_auth_repository.UserAuthRepository()
                user = user_auth_repository_var.get_user_by_email(body['emailId'])
                if not user:
                    logger.error("User not Found {}".format(body['emailId']))
                    return JsonResponse({'error': f'Error user email: {str(body['emailId'])} not found'}, status=400)
                profile_service_obj = profile_service.ProfileService()
                action = profile_service_obj.delete_profile(body,user)    
                if action:
                    return JsonResponse({'message': 'Successfully updated user'})
                else:
                    return JsonResponse({'error': f'Error updating user: {str(body['emailId'])}'}, status=500)
            except KeyError as e:
                # Return error response for missing required field
                logger.error(e)
                return JsonResponse({'error': f'Missing required field: {e}'}, status=400)
            except Exception as e:
                # Return error response for any unexpected exception
                logger.error(e)
                return JsonResponse({'error': f'Error updating user: {str(e)}'}, status=500)
    else:
        # Return error response for invalid request method
        return JsonResponse({'error': 'Invalid request method'}, status=405)

@csrf_exempt
@api_view(['GET'])
@permission_classes([IsAuthenticated])
# Handle POST request for creating and updating profile
def get_profile_pic(request):
    if request.method == 'GET':
                try:
                    parsed_req= MultiPartParser(request.META, request, request.upload_handlers).parse()
                    body = parsed_req[0]
                    # get the user using repository method
                    user_auth_repository_var = user_auth_repository.UserAuthRepository()
                    user = user_auth_repository_var.get_user_by_email(body['emailId'])
                    if not user:
                        logger.error("User not Found {}".format(body['emailId']))
                        return JsonResponse({'error': f'Error user email: {str(body['emailId'])} not found'}, status=400)
                    profile_repo_obj = profile_repository.ProfileRepository()
                    profile = profile_repo_obj.get_profile_by_user_id(user)
                    if profile:
                        s3_service_obj = s3_service.S3Service()
                        file = s3_service_obj.download_object(list(profile.values())[0]["profile_photo_key"])
                        return HttpResponse(file, content_type='image/jpeg')
                    else:
                        return JsonResponse({'error': f'Error fetching user: {str(body['emailId'])}'}, status=500)
                except KeyError as e:
                    # Return error response for missing required field
                    logger.error(e)
                    return JsonResponse({'error': f'Missing required field: {e}'}, status=400)
                except Exception as e:
                    # Return error response for any unexpected exception
                    logger.error(e)
                    return JsonResponse({'error': f'Error getching profile pic: {str(e)}'}, status=500)
    else:
        # Return error response for invalid request method
        return JsonResponse({'error': 'Invalid request method'}, status=405)
    
@csrf_exempt
@api_view(['GET'])
@permission_classes([IsAuthenticated])
# Handle POST request for creating and updating profile
def get_avatar_pic(request):
    if request.method == 'GET':
                try:
                    parsed_req= MultiPartParser(request.META, request, request.upload_handlers).parse()
                    body = parsed_req[0]
                    # get the user using repository method
                    user_auth_repository_var = user_auth_repository.UserAuthRepository()
                    user = user_auth_repository_var.get_user_by_email(body['emailId'])
                    if not user:
                        logger.error("User not Found {}".format(body['emailId']))
                        return JsonResponse({'error': f'Error user email: {str(body['emailId'])} not found'}, status=400)
                    profile_repo_obj = profile_repository.ProfileRepository()
                    profile = profile_repo_obj.get_profile_by_user_id(user)
                    if profile:
                        s3_service_obj = s3_service.S3Service()
                        file = s3_service_obj.download_object(list(profile.values())[0]["avatar_bucket_key"])
                        return HttpResponse(file, content_type='image/jpeg')
                    else:
                        return JsonResponse({'error': f'Error fetching profile: {str(body['emailId'])}'}, status=500)
                except KeyError as e:
                    # Return error response for missing required field
                    logger.error(e)
                    return JsonResponse({'error': f'Missing required field: {e}'}, status=400)
                except Exception as e:
                    # Return error response for any unexpected exception
                    logger.error(e)
                    return JsonResponse({'error': f'Error fetching avatar pic: {str(e)}'}, status=500)
    else:
        # Return error response for invalid request method
        return JsonResponse({'error': 'Invalid request method'}, status=405)