from ..models import Profile
class ProfileRepository:
    # saves profile
    def save_profile(self,profile):
        return profile.save()
    #gets profile by user auth
    def get_profile_by_user_id(self,user_auth):
        return Profile.objects.filter(user=user_auth)

