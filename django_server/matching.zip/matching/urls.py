from django.urls import path
from matching import views

urlpatterns = [
    # Endpoint for validating otp
    path('profile/', views.handle_profile, name='create_profile'),
    path('profile/profilePic', views.get_profile_pic, name='get_profile_pic'),
    path('profile/avatarPic', views.get_avatar_pic, name='get_avatar_pic'),
]
