from django.db import models

class Profile(models.Model):
    full_name = models.CharField(max_length=100,null=True)
    profile_id = models.AutoField(primary_key=True)
    user = models.ForeignKey("user_account.UserAuth",on_delete=models.CASCADE,unique=True)
    gender = models.CharField(max_length=50,null=True)
    avatar_bucket_key = models.TextField(null=True)
    profile_photo_key = models.TextField(null=True)
    languages = models.TextField(null=True)
    ethnicity = models.TextField(null=True)
    user_bio = models.TextField(null=True)
    current_addreess = models.TextField(null=True)
    work_address = models.TextField(null=True)
    hometown = models.TextField(null=True)
    interests = models.TextField(null=True)
    preferred_commute_times = models.TextField(null=True)

    def __str__(self):
        return "{} - {} -{}".format(self.full_name,self.email_id,self.phone_number)
